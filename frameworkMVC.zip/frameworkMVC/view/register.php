
<h1>INSCRIVEZ-VOUS !</h1>

<form action="?ctrl=security&method=register" method="post">
    <p><input placeholder="Votre pseudo..." type="text" name="username"></p>
    <p><input placeholder="Votre mot de passe..." type="password" name="pass1"></p>
    <p><input placeholder="Répétez le mot de passe..." type="password" name="pass2"></p>
    <p><input type="submit" value="Inscription"></p>
</form>