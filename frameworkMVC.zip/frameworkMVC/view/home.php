
<h2>BIENVENUE <?= App\Session::getUser() ?> !</h2>

<p>
    Lorem ipsum dolor sit amet consectetur adipisicing elit. Animi dolor commodi suscipit illum 
    quaerat accusamus eum ex maxime quam provident aut, voluptatum explicabo rem tempora 
    ipsam perspiciatis laborum error sunt?
</p>
